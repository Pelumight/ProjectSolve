package com.tauseef.whatsapp.whatsapp_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
